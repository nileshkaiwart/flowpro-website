FLOWPRO SAAS WEBSITE
=====================

Files:
- index.html  -> complete webpage
- style.css   -> responsive styling
- script.js   -> mobile menu + contact form demo

How to use:
1. Keep all three files in the same folder.
2. Open index.html in a browser.
3. Replace the sample FlowPro text, pricing, portfolio items and contact details with the real company information.

Note: The contact form is a front-end demo; it does not send email until connected to a backend/form service.
