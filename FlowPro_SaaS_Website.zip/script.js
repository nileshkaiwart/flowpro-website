document.querySelector('.menu').addEventListener('click',()=>{document.querySelector('.nav nav').classList.toggle('mobile-open')});
function sendMessage(e){e.preventDefault();document.getElementById('form-msg').textContent='✓ Thanks! Your message has been received.';e.target.reset();}
